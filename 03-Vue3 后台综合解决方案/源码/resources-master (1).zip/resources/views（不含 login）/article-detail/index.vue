<template>
  <div class="">文章详情</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped></style>
