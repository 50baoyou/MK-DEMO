<template>
  <div class="">创建文章</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped></style>
