<template>
  <div class="">文章排名</div>
</template>

<script setup>
import {} from 'vue'
</script>

<style lang="scss" scoped></style>
