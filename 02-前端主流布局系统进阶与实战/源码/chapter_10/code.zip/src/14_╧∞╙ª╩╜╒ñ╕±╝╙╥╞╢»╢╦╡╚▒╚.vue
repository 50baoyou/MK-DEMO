<template>
  <div>
    <h2>响应式栅格加移动端等比</h2>
    <div class="sm:grid sm:grid-cols-12">
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">aaaaaaa</div>
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">bbbbbbb</div>
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">ccccccc</div>
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">ddddddd</div>
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">eeeeeee</div>
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">fffffff</div>
      <div class="border h-24 sm:col-span-6 md:col-span-4 lg:col-span-3 xl:col-span-2">ggggggg</div>
    </div>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>