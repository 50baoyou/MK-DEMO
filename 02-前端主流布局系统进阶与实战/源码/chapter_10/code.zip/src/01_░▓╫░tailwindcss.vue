<template>
  <div>
    <!-- alt + shift + f -->
    <h1 class="text-3xl font-bold underline">Hello world!</h1>
  </div>
</template>

<script setup></script>

<style scoped></style>
