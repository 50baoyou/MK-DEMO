<template>
  <div>
    <h2>表格与表单</h2>
    <!-- <table class="w-96 border border-separate border-spacing-4 border-slate-500 table-fixed">
      <thead>
        <tr>
          <th class="border border-slate-500">编号</th>
          <th class="border border-slate-500">姓名</th>
          <th class="border border-slate-500">年龄</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="border border-slate-500">1</td>
          <td class="border border-slate-500">小明小明小明小明</td>
          <td class="border border-slate-500">20</td>
        </tr>
        <tr>
          <td class="border border-slate-500">1</td>
          <td class="border border-slate-500">小明</td>
          <td class="border border-slate-500">20</td>
        </tr>
        <tr>
          <td class="border border-slate-500">1</td>
          <td class="border border-slate-500">小明</td>
          <td class="border border-slate-500">20</td>
        </tr>
        <tr>
          <td class="border border-slate-500">1</td>
          <td class="border border-slate-500">小明</td>
          <td class="border border-slate-500">20</td>
        </tr>
      </tbody>
    </table> -->
    <input type="checkbox" checked class="accent-red-500">
    <input type="radio" checked class="accent-red-500">
    <input type="text" class="border caret-red-500">
    <textarea name="" id="" cols="30" rows="10" class="border resize"></textarea>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>