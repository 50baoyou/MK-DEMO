import { createApp } from 'vue'
import './style.css'
import App from './20_blog.vue'

createApp(App).mount('#app')
