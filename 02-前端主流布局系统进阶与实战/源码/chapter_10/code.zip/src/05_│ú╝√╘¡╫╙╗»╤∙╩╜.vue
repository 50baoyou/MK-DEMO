<template>
  <div>
    <h2>常见原子化样式</h2>
    <!-- <div class=" bg-black">aaaaaaaaaa</div>
    <div class=" bg-white">aaaaaaaaaa</div>
    <div class=" bg-red-500">aaaaaaaaaa</div>
    <div class=" bg-blue-500">aaaaaaaaaa</div>
    <div class=" bg-gradient-to-r from-blue-500 to-red-500">bbbbbbbbbbb</div> -->
    <!-- <div class=" w-96 h-96" style="background-image: url(./src/assets/1.jpg);">cccccccc</div> -->
    <!-- <br>
    <div class="w-96 h-96 shadow-orange-700 shadow-2xl">aaaaaaaaaaa</div> -->
    <!-- <br>
    <div class="opacity-50">aaaaaaaaaaa</div>
    <div class="opacity-20">bbbbbbbbbbb</div> -->
    <!-- <div class="block">ccccccccc</div>
    <div class="inline-block">ccccccccc</div>
    <div class="flex">ccccccccc</div>
    <div class="grid">ccccccccc</div>
    <div class="hidden">ccccccccc</div> -->
    <!-- <div class="overflow-hidden border">
      <div class="float-left">aaaaaaaaa</div>
    </div> -->

    <div class=" float-left clear-left">bbbbbbbbbbb</div>
    <div class=" absolute -left-60 bottom-40">cccccc</div>
    <div class=" relative">cccccc</div>
    <div class=" fixed">cccccc</div>
    <div class=" sticky">cccccc</div>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>