<template>
  <div>
    <h2>响应式布局</h2>

    <!-- tailwindcss 是移动优先的响应式设计 -->
    <!-- <div class="bg-red-500 2xl:w-full xl:w-1/2 lg:w-1/3 md:w-1/4 sm:w-1/6">aaaaaaaaaaaaa</div> -->

    <!-- <div class="bg-red-900 sm:bg-red-700 md:bg-red-500 lg:bg-red-300 xl:bg-red-100 2xl:bg-red-100/50">
      aaaaaaaaaaaaa
    </div> -->

    <!-- <div class="lg:bg-red-500">bbbbbbb</div>
    <div class="max-lg:bg-red-500">ccccccc</div> -->

    <!-- <div class="md:max-lg:bg-red-500">ddddddddd</div> -->

    <!-- <div class="min-[500px]:max-[800px]:bg-red-500">eeeeeeeeee</div> -->

    <div class=" portrait:bg-red-500 landscape:bg-blue-500">fffffffffffffff</div>
  </div>
</template>

<script setup></script>

<style scoped></style>
