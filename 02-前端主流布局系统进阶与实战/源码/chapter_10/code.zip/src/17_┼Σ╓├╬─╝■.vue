<template>
  <div>
    <h2>配置文件</h2>

    <!-- <div class="animate-slide">aaaa</div> -->

    <input type="text">
    <input type="checkbox">
    <textarea name="" id="" cols="30" rows="10"></textarea>
  </div>
</template>

<script setup>

</script>

<style scoped>

</style>