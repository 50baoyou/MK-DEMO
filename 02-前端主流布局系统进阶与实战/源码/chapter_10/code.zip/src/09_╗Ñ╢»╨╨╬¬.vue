<template>
  <div>
    <h2>互动行为</h2>
    <!-- <button class="cursor-auto">点击</button>
    <button class="cursor-pointer">点击</button>
    <button class="cursor-text">点击</button>
    <button class="cursor-move">点击</button> -->
    <!-- <br>
    <div class="w-64 h-64 border overflow-scroll touch-none">
      <div class="w-96 h-96">
        <img class="w-full h-full" src="./assets/1.jpg" alt="">
      </div>
    </div> -->
    <!-- <br />
    <div class="select-all">测试文字，hello world，测试文字</div>
    <div class="select-none">测试文字，hello world，测试文字</div> -->
    <div class="!flex !w-24 !select-all">aaaaa</div>
  </div>
</template>

<script setup></script>

<style scoped></style>
