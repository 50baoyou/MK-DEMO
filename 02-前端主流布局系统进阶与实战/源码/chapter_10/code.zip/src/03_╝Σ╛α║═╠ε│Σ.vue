<template>
  <div>
    <h2>间距和填充</h2>
    <!-- <div class="m-20">aaaaa</div>
    <div class="-m-2">aaaaa</div>
    <div class="m-[100px]">aaaaa</div>
    <div class="p-20">bbbb</div> -->
    <!-- <div class=" space-y-7">
      <div>aaaa</div>
      <div>bbbb</div>
      <div>cccc</div>
    </div> -->
    <div class="flex space-x-7">
      <div>aaaa</div>
      <div>bbbb</div>
      <div>cccc</div>
    </div>
  </div>
</template>

<script setup></script>

<style scoped></style>
